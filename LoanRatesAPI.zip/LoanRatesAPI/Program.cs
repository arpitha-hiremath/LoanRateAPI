using LoanRatesAPI.Interfaces;
using LoanRatesAPI.Models;
using LoanRatesAPI.Services;
using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Components.Forms;
//using Microsoft.AspNetCore.Http.HttpResults;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<IRateService,RateService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/api/rates", (string loanType, int term, [FromServices] IRateService rateService) =>
{
    var rates = rateService.GetRates(loanType, term);
    return Results.Ok(rates);

}).WithName("GetRates");
//.WithOpenApi();

app.Run();
