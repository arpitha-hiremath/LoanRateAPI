# LOANRATESAPI - Minimal API

This API returns mock loan data based on the loantype and term parameters.

##How to Run

1. Run "dotnet run" in the ternimal.
2. Go to "http://localhost:5034/swagger/index.html" to test the api.

## Swagger End-point

http://localhost:5034/swagger/index.html

## SOLID Princiuples

Single Responsibility: Services and Model have  distinct responsibilities.
Open/Closed: New loan types and terms can be added.
Liskov Substitution principle: Interface enable interchangeable implementations.
Interface segregation: Interface contain what is needed (IRateService.cs)
Dependency Inversion: Logic depends on abstraction (IRateService and RateService), not on concrete classes.

## Sample response

Response body:

[
  {
    "loanType": "owner-occupied",
    "term": 30
  }
]

Response headers :

content-type: application/json; charset=utf-8 
date: Thu,12 Jun 2025 04:01:53 GMT 
server: Kestrel 
transfer-encoding: chunked 
