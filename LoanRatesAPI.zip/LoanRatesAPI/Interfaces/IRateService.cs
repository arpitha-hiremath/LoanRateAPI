using LoanRatesAPI.Models;

namespace LoanRatesAPI.Interfaces
{
    public interface IRateService
    {
        IEnumerable<Rate> GetRates(string loanType, int term);
    }
}