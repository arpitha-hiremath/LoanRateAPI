namespace LoanRatesAPI.Models
{
    public class Rate
    {
        public string LoanType { get; set; }
        public int Term { get; set; }
    }
}