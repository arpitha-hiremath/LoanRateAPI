using LoanRatesAPI.Interfaces;
using LoanRatesAPI.Models;

namespace LoanRatesAPI.Services
{
    public class RateService : IRateService
    {
        public IEnumerable<Rate> GetRates(string loanType, int term)
        {
            var rates = new List<Rate>
            {
                new Rate {LoanType="owner-occupied",Term=30},
                new Rate {LoanType="investor",Term=20},
                new Rate {LoanType="owner-occupied",Term=10},
                new Rate {LoanType="owner-occupied",Term=15},
                new Rate {LoanType="investor",Term=25}
            };
            return rates.Where(r => r.LoanType == loanType && r.Term == term);
        }
    }
}